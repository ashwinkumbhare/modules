<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<div id="history_check_in_out" class="hide reports_fr">
   <table class="table table-history_check_in_out_report scroll-responsive">
    <thead>
      <tr>
         <th><?php echo _l('staffid'); ?></th>
         <th><?php echo _l('time'); ?></th>
         <th ><?php echo _l('type'); ?></th>
         <th><?php echo _l('shift'); ?></th>
         <th><?php echo _l('workplace'); ?></th>
         <th><?php echo _l('route'); ?></th>
      </tr>
   </thead>
   <tbody></tbody>
   <tfoot>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
   </tfoot>
</table>
</div>
