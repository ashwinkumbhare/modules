<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<div class="relative leave_by_department"class="hide reports_fr">
   <div id="leave_by_department" class="reports"></div>
</div>